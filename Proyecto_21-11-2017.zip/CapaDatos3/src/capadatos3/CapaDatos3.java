/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capadatos3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Emiliano
 */
public class CapaDatos3 {

   Connection co;    
Statement st;
String host="jdbc:mysql://localhost/mydb1";
String user="root";
String password="root";
    
public void insertarRegistroCliente (int dni,String nom,String ap,String te,String dir)
{
     try
    {
    Class.forName("com.mysql.jdbc.Driver");
    
    
   co= DriverManager.getConnection(host, user, password);
   st=co.createStatement();
   
   String sentencia="insert into cliente values ("+dni+",'"+nom+"','"+ap+"','"+te+"','"+dir+"');";
    
   st.executeUpdate(sentencia);
   
    }catch(ClassNotFoundException ex){
        ex.printStackTrace();
    }catch(SQLException ex)
    {
        ex.printStackTrace();
    }
    
    
}
    
public void insertarRegistroAlquiler (int idPelicula,int idCliente,Date retiro,Date devolucion)
{
    try
    {
              SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");
        
        String fechaInicio=sdf.format(retiro);
        
        Class.forName("com.mysql.jdbc.Driver");

        co= DriverManager.getConnection(host, user, password);
        st=co.createStatement();

        String sentencia="insert into Alquileres (Retiro,devolucion,cliente_dni,producto_idproducto) values ('"+retiro+"','"+idPelicula+"','"+idCliente+"','"+retiro+"','"+devolucion+"');";

        st.executeUpdate(sentencia);

         }catch(ClassNotFoundException ex){
             ex.printStackTrace();
         }catch(SQLException ex)
         {
             ex.printStackTrace();
         }
    }   

public void insertarProducto (String descripcion,double precio)
{
     try
    {
        Class.forName("com.mysql.jdbc.Driver");
       co= DriverManager.getConnection(host, user, password);
       st=co.createStatement();

       String sentencia="insert into  producto (Descripcion,Precio) values ('"+descripcion+"',"+precio+");";

       st.executeUpdate(sentencia);

        }catch(ClassNotFoundException ex){
            ex.printStackTrace();
        }catch(SQLException ex)
        {
            ex.printStackTrace();
        }


    }
}
