/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capanegocio3;

import capadatos3.CapaDatos3;
import java.util.ArrayList;

/**
 *
 * @author Emiliano
 */
public class Administradora {

    private ArrayList <Cliente> cliente=new ArrayList();
    private ArrayList <Producto> producto=new ArrayList();
    private ArrayList <Alquiler> alquiler=new ArrayList();

    public ArrayList<Cliente> getCliente() {
        return cliente;
    }

    public ArrayList<Producto> getProducto() {
        return producto;
    }

    public ArrayList<Alquiler> getAlquiler() {
        return alquiler;
    }

    public void setCliente(ArrayList<Cliente> cliente) {
        this.cliente = cliente;
    }

    public void setProducto(ArrayList<Producto> producto) {
        this.producto = producto;
    }

    public void setAlquiler(ArrayList<Alquiler> alquiler) {
        this.alquiler = alquiler;
    }

    public Administradora() {
    }

    public void AddCliente (Cliente client){
        //Agregamos en memoria
        cliente.add(client);
        //Agregamos en bd
        CapaDatos3 datos = new CapaDatos3();
        datos.insertarRegistroCliente(client.getDni(),client.getNombre(), client.getApellido(), client.getTelefono(),
                client.getDireccion());
    }
    
    
   
     public void AddProducto (Producto prod){
        //Agregamos en memoria
        producto.add(prod);
        CapaDatos3 datos = new CapaDatos3();
        datos.insertarProducto(prod.getNombre(), prod.getPrecio());
        
    }
     
     public void AddAlquiler(Alquiler alq){
        alquiler.add(alq);
        //CapaDatos3 datos = new CapaDatos3();
       // datos.insertarRegistroAlquiler(alq.getIdAlquiler(), alq.getCliente().getDni(), alq.getFechaInicio());
     }
   
    
}
